using System.Data.SqlClient;
using System.Data;
using System.Drawing.Imaging;


namespace Practica_Individual_IncisoA
{
    public partial class Form1 : Form
    {

        Bitmap imagenOriginal;
        string cadena = @"server=.\SQLEXPRESS;user=inf273;pwd=123456;database=texturaPracticaA;TrustServerCertificate=True";
        Color c = Color.Empty;


        public Form1()
        {
            InitializeComponent();
            ActualizarTabla();
            comboBox1.Items.Add("cesped");
            comboBox1.Items.Add("tierra");
            comboBox1.Items.Add("cemento");
            comboBox1.Items.Add("asfalto");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            //op.Filter = "Imagen|*.jpg;*.png;*.bmp";
            op.Filter= "Archivo JPG|*.jpg|Archivos PNG|*.png";

            if (op.ShowDialog() == DialogResult.OK)
            {
                imagenOriginal=new Bitmap(op.FileName);
                pictureBox1.Image = imagenOriginal;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (imagenOriginal == null)
                return;

            if (c == Color.Empty)
            {
                MessageBox.Show("Primero haz clic en alguna parte de la imagen","aviso",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(comboBox1.Text))
            {
                MessageBox.Show("Selecccione alguna categoria", "aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string sql = "INSERT INTO MuestrasTextura(categoria,r,g,b)VALUES(@cat,@r,@g,@b)";
            
            using (SqlConnection cn = new SqlConnection(cadena))
            {
                SqlCommand cmd = new SqlCommand(sql, cn);

                cmd.Parameters.AddWithValue("@cat", comboBox1.Text);

                cmd.Parameters.AddWithValue("@r", c.R);
                cmd.Parameters.AddWithValue("@g", c.G);
                cmd.Parameters.AddWithValue("@b", c.B);

                cn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show($"Muestra de '{comboBox1.Text}' guardada correctamente");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (imagenOriginal == null) return;

            Bitmap salida = new Bitmap(imagenOriginal);
            List<(string cat, int r, int g, int b)> muestras = new List<(string, int, int, int)>();

            using (SqlConnection cn = new SqlConnection(cadena))
            {
                cn.Open();
                SqlCommand cmd = new SqlCommand("SELECT categoria,r,g,b FROM MuestrasTextura", cn);
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    muestras.Add((
                        dr.GetString(0),
                        dr.GetInt32(1),
                        dr.GetInt32(2),
                        dr.GetInt32(3)
                    ));
                }
            }

            if (muestras.Count == 0)
            {
                MessageBox.Show("No hay muestras en la base de datos para clasificar.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            for (int x = 0; x < salida.Width; x++)
            {
                for (int y = 0; y < salida.Height; y++)
                {
                    Color pix = imagenOriginal.GetPixel(x, y);

                    string mejorCat = "";
                    double menor = double.MaxValue;

                    foreach (var m in muestras)
                    {
                        double d = Math.Sqrt(
                            Math.Pow(pix.R - m.r, 2) +
                            Math.Pow(pix.G - m.g, 2) +
                            Math.Pow(pix.B - m.b, 2));

                        if (d < menor)
                        {
                            menor = d;
                            mejorCat = m.cat;
                        }
                    }

                    if (mejorCat == "cesped") salida.SetPixel(x, y, Color.Green);
                    else if (mejorCat == "tierra") salida.SetPixel(x, y, Color.Brown);
                    else if (mejorCat == "cemento") salida.SetPixel(x, y, Color.Gray);
                    else if (mejorCat == "asfalto") salida.SetPixel(x, y, Color.Black);
                }
            }

            pictureBox2.Image = salida;

        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (imagenOriginal == null)
                return;

            

            int posX = e.X * imagenOriginal.Width / pictureBox1.Width;
            int posY = e.Y * imagenOriginal.Height / pictureBox1.Height;

            c = imagenOriginal.GetPixel(posX, posY);

            textBox1.Text = c.R.ToString();
            textBox2.Text = c.G.ToString();
            textBox3.Text = c.B.ToString();

        }
        private void ActualizarTabla()
        {
            try
            {
                string consulta = "SELECT id, categoria, r, g, b FROM MuestrasTextura"; // Ajusta 'id' si tu llave primaria se llama distinto

                using (SqlConnection cn = new SqlConnection(cadena))
                {
                    SqlDataAdapter da = new SqlDataAdapter(consulta, cn);
                    DataTable dt = new DataTable();

                    da.Fill(dt);
                    dataGridView1.DataSource = dt; // Muestra los datos en el DataGridView
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar los datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

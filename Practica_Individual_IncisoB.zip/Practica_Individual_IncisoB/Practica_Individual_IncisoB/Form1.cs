using System;
using System.Drawing;
using System.Windows.Forms;

namespace Practica_Individual_IncisoB

{
    public partial class Form1 : Form
    {
        Bitmap imagenOriginal;
        public Form1()
        {
            InitializeComponent();

        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            openFileDialog1.Filter = "Archivo JPG|*.jpg|Archivos PNG|*.png";
            openFileDialog1.ShowDialog();
            imagenOriginal = new Bitmap(openFileDialog1.FileName);
            pictureBox1.Image = imagenOriginal;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (imagenOriginal == null)
                return;

            Bitmap salida = new Bitmap(imagenOriginal);

            int pasadas = 2;

            for (int pasada = 0; pasada < pasadas; pasada++)
            {
                
                Bitmap imagenEntradaPasada = new Bitmap(salida);

                for (int x = 1; x < imagenOriginal.Width - 1; x++)
                {
                    for (int y = 1; y < imagenOriginal.Height - 1; y++)
                    {
                        int r = 0;
                        int g = 0;
                        int b = 0;

                        //para el 3x3
                        for (int i = -1; i <= 1; i++)
                        {
                            for (int j = -1; j <= 1; j++)
                            {
                                
                                Color c = imagenEntradaPasada.GetPixel(x + i, y + j);
                                r += c.R;
                                g += c.G;
                                b += c.B;
                            }
                        }

                        r = r / 9;
                        g = g / 9;
                        b = b / 9;

                        salida.SetPixel(x, y, Color.FromArgb(r, g, b));
                    }
                }

                //borramos al copia para q no sea pesado
                imagenEntradaPasada.Dispose();
            }

            pictureBox2.Image = salida;
        }
    }
}